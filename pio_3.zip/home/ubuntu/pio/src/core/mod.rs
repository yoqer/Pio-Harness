pub mod channel;
pub mod memory;
pub mod capabilities;

use anyhow::Result;
use crate::core::channel::{IncomingMessage, OutgoingMessage};
use crate::core::memory::MemoryManager;
use crate::core::capabilities::{CapabilityRequest, CapabilityMode};
use std::sync::Arc;
use reqwest::Client;
use serde_json::json;

pub struct AgentProcessor {
    memory: Arc<MemoryManager>,
    http_client: Client,
}

impl AgentProcessor {
    pub fn new() -> Self {
        Self {
            memory: Arc::new(MemoryManager::new()),
            http_client: Client::new(),
        }
    }

    pub async fn process_message(&self, msg: IncomingMessage) -> Result<OutgoingMessage> {
        log::info!("Procesando mensaje de {}: {}", msg.user_id, msg.content);
        
        // Detección de comandos especiales para capacidades
        if msg.content.starts_with("!translate") {
            let content = msg.content.replace("!translate", "").trim().to_string();
            let res = self.handle_capability(CapabilityRequest {
                mode: CapabilityMode::Translate,
                content,
                provider: std::env::var("TRANSLATE_PROVIDER").unwrap_or_else(|_| "qwen".to_string()),
                language: Some("es".to_string()),
            }).await?;
            return Ok(OutgoingMessage { content: res });
        }

        if msg.content.starts_with("!reason") {
            let content = msg.content.replace("!reason", "").trim().to_string();
            let res = self.handle_capability(CapabilityRequest {
                mode: CapabilityMode::Reasoning,
                content,
                provider: std::env::var("REASONING_PROVIDER").unwrap_or_else(|_| "deepseek".to_string()),
                language: None,
            }).await?;
            return Ok(OutgoingMessage { content: res });
        }

        // 1. Recuperar contexto de memoria Engram
        let context = self.memory.get_context(&msg.user_id, 5).await?;
        
        // 2. Determinar proveedor (Local, API, Grok, Gemini, etc.)
        let api_base = std::env::var("LLM_API_BASE").unwrap_or_else(|_| "https://api.openai.com/v1".to_string());
        let model = std::env::var("LLM_MODEL_NAME").unwrap_or_else(|_| "gpt-4o".to_string());
        
        // 3. Llamada al LLM
        let response_text = if api_base.contains("localhost") || api_base.contains("127.0.0.1") {
            match self.call_local_llm(&api_base, &model, &context, &msg.content).await {
                Ok(res) => res,
                Err(e) => format!("Error llamando al LLM local: {}", e),
            }
        } else {
            format!("Respuesta de Pio: Recibí '{}'. Contexto previo: {}...", msg.content, context.chars().take(30).collect::<String>())
        };

        // 4. Guardar en memoria Engram
        let mut metadata = std::collections::HashMap::new();
        metadata.insert("channel".to_string(), msg.channel_id);
        self.memory.add_engram(&msg.user_id, msg.content, metadata).await?;

        Ok(OutgoingMessage {
            content: response_text,
        })
    }

    async fn call_local_llm(&self, base_url: &str, model: &str, context: &str, prompt: &str) -> Result<String> {
        let url = format!("{}/chat/completions", base_url);
        let body = json!({
            "model": model,
            "messages": [
                {"role": "system", "content": format!("Eres un asistente útil llamado Pio. Contexto previo:\n{}", context)},
                {"role": "user", "content": prompt}
            ]
        });

        let res = self.http_client.post(&url)
            .json(&body)
            .send()
            .await?;

        if res.status().is_success() {
            let json: serde_json::Value = res.json().await?;
            Ok(json["choices"][0]["message"]["content"].as_str().unwrap_or("Error en respuesta").to_string())
        } else {
            Ok(format!("Error del servidor local ({}): {}", res.status(), res.text().await?))
        }
    }
}
