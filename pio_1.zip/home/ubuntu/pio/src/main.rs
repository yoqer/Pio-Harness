mod core;
mod channels;
mod harness;
mod tools;

use crate::core::AgentProcessor;
use std::sync::Arc;
use dotenv::dotenv;
use anyhow::Result;

#[tokio::main]
async fn main() -> Result<()> {
    dotenv().ok();
    env_logger::init();

    log::info!("Iniciando Omni Agent Harness Framework...");

    let processor = Arc::new(AgentProcessor::new());
    let mut tasks = Vec::new();

    // Cargar adaptador de Telegram si la feature está activa
    #[cfg(feature = "telegram")]
    {
        if let Ok(token) = std::env::var("TELEGRAM_TOKEN") {
            let adapter = channels::telegram::TelegramAdapter::new(token, processor.clone());
            tasks.push(tokio::spawn(async move {
                if let Err(e) = crate::core::channel::ChannelAdapter::start(&adapter).await {
                    log::error!("Error en adaptador de Telegram: {}", e);
                }
            }));
        }
    }

    // Aquí se añadirían otros adaptadores (Discord, Email, etc.)

    if tasks.is_empty() {
        log::warn!("No se han iniciado canales. Asegúrate de configurar las variables de entorno y activar las features correspondientes.");
    }

    // Mantener la aplicación ejecutándose
    for task in tasks {
        let _ = task.await;
    }

    Ok(())
}
