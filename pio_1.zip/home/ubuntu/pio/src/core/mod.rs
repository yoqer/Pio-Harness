pub mod channel;
pub mod memory;

use anyhow::Result;
use crate::core::channel::{IncomingMessage, OutgoingMessage};
use crate::core::memory::MemoryManager;
use std::sync::Arc;
use reqwest::Client;
use serde_json::json;

pub struct AgentProcessor {
    memory: Arc<MemoryManager>,
    http_client: Client,
}

impl AgentProcessor {
    pub fn new() -> Self {
        Self {
            memory: Arc::new(MemoryManager::new()),
            http_client: Client::new(),
        }
    }

    pub async fn process_message(&self, msg: IncomingMessage) -> Result<OutgoingMessage> {
        log::info!("Procesando mensaje de {}: {}", msg.user_id, msg.content);
        
        // 1. Recuperar contexto de memoria Engram
        let context = self.memory.get_context(&msg.user_id, 5).await?;
        
        // 2. Determinar si usar LLM Local o API (vía variables de entorno)
        let api_base = std::env::var("LOCAL_LLM_API_BASE").unwrap_or_else(|_| "https://api.openai.com/v1".to_string());
        let model = std::env::var("LOCAL_LLM_MODEL_NAME").unwrap_or_else(|_| "gpt-3.5-turbo".to_string());
        
        log::debug!("Usando LLM en {} con modelo {}", api_base, model);

        // 3. Llamada al LLM (simulada o real si hay API key)
        let response_text = if api_base.contains("localhost") || api_base.contains("127.0.0.1") {
            match self.call_local_llm(&api_base, &model, &context, &msg.content).await {
                Ok(res) => res,
                Err(e) => format!("Error llamando al LLM local: {}", e),
            }
        } else {
            format!("Respuesta de Pio: Recibí '{}'. Contexto previo: {}...", msg.content, context.chars().take(30).collect::<String>())
        };

        // 4. Guardar en memoria Engram
        let mut metadata = std::collections::HashMap::new();
        metadata.insert("channel".to_string(), msg.channel_id);
        self.memory.add_engram(&msg.user_id, msg.content, metadata).await?;

        Ok(OutgoingMessage {
            content: response_text,
        })
    }

    async fn call_local_llm(&self, base_url: &str, model: &str, context: &str, prompt: &str) -> Result<String> {
        let url = format!("{}/chat/completions", base_url);
        let body = json!({
            "model": model,
            "messages": [
                {"role": "system", "content": format!("Eres un asistente útil llamado Pio. Contexto previo:\n{}", context)},
                {"role": "user", "content": prompt}
            ]
        });

        let res = self.http_client.post(&url)
            .json(&body)
            .send()
            .await?;

        if res.status().is_success() {
            let json: serde_json::Value = res.json().await?;
            Ok(json["choices"][0]["message"]["content"].as_str().unwrap_or("Error en respuesta").to_string())
        } else {
            Ok(format!("Error del servidor local ({}): {}", res.status(), res.text().await?))
        }
    }
}
