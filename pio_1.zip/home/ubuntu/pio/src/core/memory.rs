use serde::{Serialize, Deserialize};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use anyhow::Result;
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Engram {
    pub id: String,
    pub content: String,
    pub timestamp: DateTime<Utc>,
    pub metadata: HashMap<String, String>,
}

pub struct MemoryManager {
    // Memoria engramática persistente (simulada con un mapa para este ejemplo)
    engrams: Arc<RwLock<HashMap<String, Vec<Engram>>>>,
}

impl MemoryManager {
    pub fn new() -> Self {
        Self {
            engrams: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    pub async fn add_engram(&self, user_id: &str, content: String, metadata: HashMap<String, String>) -> Result<()> {
        let mut engrams = self.engrams.write().await;
        let user_engrams = engrams.entry(user_id.to_string()).or_insert(Vec::new());
        
        user_engrams.push(Engram {
            id: uuid::Uuid::new_v4().to_string(),
            content,
            timestamp: Utc::now(),
            metadata,
        });
        
        Ok(())
    }

    pub async fn get_context(&self, user_id: &str, limit: usize) -> Result<String> {
        let engrams = self.engrams.read().await;
        if let Some(user_engrams) = engrams.get(user_id) {
            let context = user_engrams.iter()
                .rev()
                .take(limit)
                .map(|e| format!("[{}]: {}", e.timestamp.format("%Y-%m-%d %H:%M:%S"), e.content))
                .collect::<Vec<_>>()
                .join("\n");
            Ok(context)
        } else {
            Ok("Sin historial previo.".to_string())
        }
    }
}
