use async_trait::async_trait;
use anyhow::Result;

#[derive(Debug, Clone)]
pub struct IncomingMessage {
    pub channel_id: String,
    pub user_id: String,
    pub content: String,
}

#[derive(Debug, Clone)]
pub struct OutgoingMessage {
    pub content: String,
}

#[async_trait]
pub trait ChannelAdapter: Send + Sync {
    async fn start(&self) -> Result<()>;
    async fn send_message(&self, target_id: &str, message: OutgoingMessage) -> Result<()>;
    fn name(&self) -> &str;
}
