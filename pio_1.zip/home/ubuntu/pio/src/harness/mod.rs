use anyhow::Result;
use std::process::Command;
use std::path::PathBuf;

pub enum HarnessType {
    Local,
    Docker,
    Portable(PathBuf), // Para USB o carpetas específicas
}

pub struct Harness {
    pub harness_type: HarnessType,
}

impl Harness {
    pub fn new(harness_type: HarnessType) -> Self {
        Self { harness_type }
    }

    pub fn execute(&self, cmd: &str, args: &[&str]) -> Result<String> {
        match &self.harness_type {
            HarnessType::Local => self.execute_local(cmd, args),
            HarnessType::Docker => self.execute_docker(cmd, args),
            HarnessType::Portable(path) => self.execute_portable(path, cmd, args),
        }
    }

    fn execute_local(&self, cmd: &str, args: &[&str]) -> Result<String> {
        let output = Command::new(cmd)
            .args(args)
            .output()?;
        Ok(String::from_utf8_lossy(&output.stdout).to_string())
    }

    fn execute_docker(&self, cmd: &str, args: &[&str]) -> Result<String> {
        // Simulación de comando docker run
        let mut docker_args = vec!["run", "--rm", "pio-harness-image", cmd];
        docker_args.extend(args);
        
        let output = Command::new("docker")
            .args(&docker_args)
            .output()?;
        Ok(String::from_utf8_lossy(&output.stdout).to_string())
    }

    fn execute_portable(&self, path: &PathBuf, cmd: &str, args: &[&str]) -> Result<String> {
        let output = Command::new(cmd)
            .args(args)
            .current_dir(path)
            .output()?;
        Ok(String::from_utf8_lossy(&output.stdout).to_string())
    }
}
