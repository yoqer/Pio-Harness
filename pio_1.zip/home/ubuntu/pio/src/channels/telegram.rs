#[cfg(feature = "telegram")]
use teloxide::prelude::*;
use crate::core::channel::{ChannelAdapter, IncomingMessage, OutgoingMessage};
use crate::core::AgentProcessor;
use async_trait::async_trait;
use anyhow::Result;
use std::sync::Arc;

pub struct TelegramAdapter {
    token: String,
    processor: Arc<AgentProcessor>,
}

impl TelegramAdapter {
    pub fn new(token: String, processor: Arc<AgentProcessor>) -> Self {
        Self { token, processor }
    }
}

#[async_trait]
impl ChannelAdapter for TelegramAdapter {
    fn name(&self) -> &str {
        "Telegram"
    }

    async fn start(&self) -> Result<()> {
        log::info!("Iniciando adaptador de Telegram...");
        let bot = Bot::new(&self.token);
        let processor = self.processor.clone();

        teloxide::repl(bot, move |bot: Bot, msg: Message| {
            let processor = processor.clone();
            async move {
                if let Some(text) = msg.text() {
                    let incoming = IncomingMessage {
                        channel_id: msg.chat.id.to_string(),
                        user_id: msg.from.map(|u| u.id.to_string()).unwrap_or_default(),
                        content: text.to_string(),
                    };

                    match processor.process_message(incoming).await {
                        Ok(response) => {
                            bot.send_message(msg.chat.id, response.content).await?;
                        }
                        Err(e) => {
                            log::error!("Error procesando mensaje en Telegram: {}", e);
                        }
                    }
                }
                Ok(())
            }
        })
        .await;

        Ok(())
    }

    async fn send_message(&self, target_id: &str, message: OutgoingMessage) -> Result<()> {
        let bot = Bot::new(&self.token);
        let chat_id: i64 = target_id.parse()?;
        bot.send_message(ChatId(chat_id), message.content).await?;
        Ok(())
    }
}
