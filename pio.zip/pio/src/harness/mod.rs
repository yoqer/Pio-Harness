use anyhow::Result;
use std::process::Command;

pub struct Harness {
    pub sandbox_path: String,
}

impl Harness {
    pub fn new(sandbox_path: String) -> Self {
        Self { sandbox_path }
    }

    pub fn execute_command(&self, cmd: &str, args: &[&str]) -> Result<String> {
        log::info!("Ejecutando comando en harness: {} {:?}", cmd, args);
        
        // En una implementación real, esto usaría Docker o un sandbox más estricto
        let output = Command::new(cmd)
            .args(args)
            .current_dir(&self.sandbox_path)
            .output()?;

        if output.status.success() {
            Ok(String::from_utf8_lossy(&output.stdout).to_string())
        } else {
            let error = String::from_utf8_lossy(&output.stderr).to_string();
            anyhow::bail!("Error de ejecución: {}", error)
        }
    }
}
